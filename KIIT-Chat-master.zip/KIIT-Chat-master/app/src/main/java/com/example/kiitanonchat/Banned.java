package com.example.kiitanonchat;

public class Banned {
    String bannedUser;

    Banned(){

    }

    public Banned(String bannedUser) {
        this.bannedUser = bannedUser;
    }

}
